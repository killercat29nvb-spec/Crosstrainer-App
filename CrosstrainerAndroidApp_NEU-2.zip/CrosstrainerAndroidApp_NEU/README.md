# Crosstrainer Tracker Android-App

Enthalten:
- Trainings erfassen
- Details
- Fortschritts-Graph
- Zielauswahl
- Einzeltraining-Ziel
- lokale Speicherung
- Leistungsfarben

APK bauen:
1. ZIP entpacken.
2. In Android Studio öffnen.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).

Oder:
1. Inhalt in GitHub hochladen.
2. Actions > Build Android APK starten.
3. APK als Artifact herunterladen.
